package Week4;

public class Sum {    
	public static int sum(int a, int b) { 
		return a+b;
   }
}
