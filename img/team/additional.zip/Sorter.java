package Week4;

public interface Sorter { 
    public int[] sort(int[] inputArr);
}